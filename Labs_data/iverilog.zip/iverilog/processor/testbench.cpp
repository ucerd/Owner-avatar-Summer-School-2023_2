#include <verilated.h>
#include "Valu.h" // Include the Verilator-generated ALU header

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);

    // Instantiate the ALU module
    Valu* top = new Valu;

    // Initialize inputs
    top->op1 = 5;        // Example input value 1
    top->op2 = 3;        // Example input value 2
    top->opcode = 2;     // Example ALU opcode (customize as needed)

    // Evaluate the ALU
    top->eval();

    // Print the result
    printf("ALU Result: %d\n", top->result);

    // Clean up
    top->final();

    // Exit
    exit(0);
}
