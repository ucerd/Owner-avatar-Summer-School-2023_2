// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vdotprod.h for the primary calling header

#ifndef VERILATED_VDOTPROD___024ROOT_H_
#define VERILATED_VDOTPROD___024ROOT_H_  // guard

#include "verilated.h"


class Vdotprod__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vdotprod___024root final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    VL_IN8(clk,0,0);
    VL_IN8(rst,0,0);
    VL_IN8(Ai,7,0);
    VL_IN8(Bi,7,0);
    CData/*0:0*/ __Vtrigprevexpr___TOP__clk__0;
    CData/*0:0*/ __VactContinue;
    VL_OUT(out,25,0);
    IData/*25:0*/ dotprod__DOT__accum;
    IData/*31:0*/ __VstlIterCount;
    IData/*31:0*/ __VactIterCount;
    VlTriggerVec<1> __VstlTriggered;
    VlTriggerVec<1> __VactTriggered;
    VlTriggerVec<1> __VnbaTriggered;

    // INTERNAL VARIABLES
    Vdotprod__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vdotprod___024root(Vdotprod__Syms* symsp, const char* v__name);
    ~Vdotprod___024root();
    VL_UNCOPYABLE(Vdotprod___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
