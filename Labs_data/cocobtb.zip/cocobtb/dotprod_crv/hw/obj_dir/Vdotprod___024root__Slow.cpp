// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vdotprod.h for the primary calling header

#include "verilated.h"

#include "Vdotprod__Syms.h"
#include "Vdotprod__Syms.h"
#include "Vdotprod___024root.h"

void Vdotprod___024root___ctor_var_reset(Vdotprod___024root* vlSelf);

Vdotprod___024root::Vdotprod___024root(Vdotprod__Syms* symsp, const char* v__name)
    : VerilatedModule{v__name}
    , vlSymsp{symsp}
 {
    // Reset structure values
    Vdotprod___024root___ctor_var_reset(this);
}

void Vdotprod___024root::__Vconfigure(bool first) {
    if (false && first) {}  // Prevent unused
}

Vdotprod___024root::~Vdotprod___024root() {
}
