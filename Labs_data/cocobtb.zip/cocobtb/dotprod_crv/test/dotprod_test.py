import cocotb
from cocotb.triggers import RisingEdge, Event
from cocotb.clock import Clock
from cocotb_coverage import crv
from cocotb_coverage.coverage import *

NUM_EXECUTIONS = 10

# Generates random values for Ai and Bi
class rand_vals(crv.Randomized):
    def __init__(self):
        crv.Randomized.__init__(self)
        self.Ai = 0
        self.Bi = 0

        ########################################################################
        # Write code to generate two random 8-bit numbers for Ai and Bi
        self.add_rand("Ai", list(range(256)))
        self.add_rand("Bi", list(range(256)))


# Generates a random value for the length of the vectors
class rand_len(crv.Randomized):
    def __init__(self):
        crv.Randomized.__init__(self)
        self.N = 0

        ########################################################################
        # Write code to generate a random value between 1 and 1024
        self.add_rand("N", list(range(1,1025)))


###############################################################################
# Write decorators to compute coverage
# Target coverage:
#   - Test all the possible vector lengths
@CoverPoint("top.N",
            xf = lambda rl : rl.N,
            bins = range(1,1025))
def sample_coverage(rl):
    pass

class TestBench:
    def __init__(self, dut, N):
        self.dut = dut          # Design Under Test
        self.N = N              # Length of the vectors A and B
        self.in_vals = Event()  # Event to communicate Driver and ReferenceModel
        self.ref_out = 0        # Expected output

    ############################################################################
    # Write Driver coroutine
    # Driver provides values signals: rst, Ai and Bi
    # It generates a 1 cycle reset cycle and then it streams the two vectors
    @cocotb.coroutine
    def Driver(self):
        # Reset cycle
        self.dut.rst <= 1
        yield RisingEdge(self.dut.clk)
        yield RisingEdge(self.dut.clk)
        self.dut.rst <= 0

        # Generate N random pairs of values (Ai, Bi)
        vals = rand_vals()
        for _ in range(self.N):
            vals.randomize() # Randomize values of the vectors
            self.dut.Ai <= vals.Ai
            self.dut.Bi <= vals.Bi
            self.in_vals.set((vals.Ai, vals.Bi))
            yield RisingEdge(self.dut.clk)

    ############################################################################
    # Write ReferenceModel coroutine
    # It receives Ai and Bi via an event from Driver and computes dotprod
    @cocotb.coroutine
    def ReferenceModel(self):
        for _ in range(self.N):
            yield self.in_vals.wait()
            self.ref_out += self.in_vals.data[0] * self.in_vals.data[1]
            self.in_vals.clear()          

    ############################################################################
    # Write Checker coroutine
    # 
    @cocotb.coroutine
    def Checker(self, ref_th):
        yield ref_th.join()
        yield RisingEdge(self.dut.clk)
        yield RisingEdge(self.dut.clk)
        cocotb.log.info("    ref_out={0}, dut_out={1}".format(self.ref_out, int(self.dut.out.value)))
        assert self.dut.out == self.ref_out

    @cocotb.coroutine
    def run(self):
        cocotb.fork(self.Driver())
        ref_th = cocotb.fork(self.ReferenceModel())
        yield cocotb.fork(self.Checker(ref_th)).join()
        

@cocotb.test()
def dotprod_test(dut):
    cocotb.fork(Clock(dut.clk, 10, "ns").start())

    vec_len = rand_len()

    for i in range(NUM_EXECUTIONS):
        vec_len.randomize()
        cocotb.log.info("Test {0}: Running test with N={1}".format(i+1, vec_len.N))
        tb = TestBench(dut, vec_len.N)
        yield tb.run()
        sample_coverage(vec_len)

    coverage_db.report_coverage(cocotb.logging.getLogger("cocotb.test").info, bins=True)






