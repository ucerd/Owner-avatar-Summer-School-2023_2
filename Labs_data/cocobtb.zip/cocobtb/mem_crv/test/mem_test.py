import cocotb
from cocotb.triggers import RisingEdge
from cocotb.clock import Clock
from cocotb_coverage import crv
from cocotb_coverage.coverage import *

NUM_EXECUTIONS = 1000

L_BYTE, L_HALF, L_WORD, L_DWORD = list(range(4))

# Generates random memory transaction
class randTransaction(crv.Randomized):
    def __init__(self):
        crv.Randomized.__init__(self)
        self.we = 0
        self.addr = 0
        self.dlen = L_BYTE
        self.wdata = 0

        ########################################################################
        # Write constraints here
        #   Generate valid values for: we, addr, dlen and wdata
        #   Make sure transaction address respect the alignment

        self.add_rand("we", [0,1])
        self.add_rand("addr", list(range(2**14)))
        self.add_rand("dlen", [L_BYTE, L_HALF, L_WORD, L_DWORD])
        self.add_rand("wdata", list(range(1024)))

        def check_alignment(addr, dlen):
            if dlen == L_BYTE:   return True
            elif dlen == L_HALF: return (addr % 2) == 0
            elif dlen == L_WORD: return (addr % 4) == 0
            else:                 return (addr % 8) == 0

        self.add_constraint(check_alignment)

    def send(self, dut):
        dut.we <= self.we
        dut.addr <= self.addr
        dut.len <= self.dlen
        dut.wdata <= self.wdata



# Reference implementation of the synchronous memory
class ReferenceModel:
    def __init__(self):
        self.data = [0] * 2**14

    def process(self, t):
        if t.we:
            for i in range(1 << t.dlen):
                self.data[t.addr+i] = (t.wdata & (0xFF << (i*8))) >> (i*8)


################################################################################
# Decorate the following function to compute the coverage
# Cases to cover:
#   - Read and Write transactions
#   - All possible transaction lenghts (byte, half, word and dword)
#   - All the address that are multiple of 8
#   - All the combinations of the previous cases
@CoverPoint("top.rt.we", vname="rw", xf=lambda rt : rt.we, bins=[0,1], bins_labels=["READ", "WRITE"])
@CoverPoint("top.rt.dlen", vname="len", xf=lambda rt : rt.dlen, bins=list(range(4)), bins_labels=["BYTE", "HALF", "WORD", "DWORD"])
@CoverPoint("top.rt.addr", vname="addr", xf=lambda rt : rt.addr, bins=list(range(0,2**14,8)))
@CoverCross("top.rt.cross", items=["top.rt.we", "top.rt.dlen", "top.rt.addr"])
def sample_coverage(rt):
    pass

@cocotb.test()
def mem_test_crv(dut):
    # Initialize mem to 0
    for i in range(2**14):
        dut.data[i] = 0

    # Start clock
    cocotb.fork(Clock(dut.clk, 10, "ns").start())

    ref = ReferenceModel()
    rt = randTransaction()

    # Generate random memory transactions
    for i in range(NUM_EXECUTIONS):
        # Generate and print random memory transaction
        rt.randomize()
        cocotb.log.info("Transaction {0}: we={1}, addr={2}, len={3}, wdata={4}".format(i+1, rt.we, rt.addr, rt.dlen, rt.wdata))

        # Send transaction to reference model and to DUT
        ref.process(rt)
        rt.send(dut)

        # Update coverage database
        sample_coverage(rt)

        # Run RTL simulation until the next cycle
        yield RisingEdge(dut.clk)

    yield RisingEdge(dut.clk)

    # Check the output
    for i in range(2**14):
        if dut.data[i].value != ref.data[i]:
            cocotb.log.info("Error at addr {0}: dut.data={1}, ref.data={2}".format(i, int(dut.data[i].value), ref.data[i]))
        assert dut.data[i] == ref.data[i]

    coverage_db.report_coverage(cocotb.logging.getLogger("cocotb.test").info, bins=False)


