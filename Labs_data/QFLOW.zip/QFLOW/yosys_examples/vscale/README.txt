Download vscale source code first:

git clone https://github.com/LGTMCU/vscale


