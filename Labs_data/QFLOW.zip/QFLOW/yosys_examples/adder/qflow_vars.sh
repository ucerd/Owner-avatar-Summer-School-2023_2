#!/bin/tcsh -f
#-------------------------------------------
# qflow variables for project ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/yosys_examples/adder
#-------------------------------------------

set qflowversion=1.4.100
set projectpath=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/yosys_examples/adder
set techdir=/usr/local/share/qflow/tech/gscl45nm
set sourcedir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/yosys_examples/adder/source
set synthdir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/yosys_examples/adder/synthesis
set layoutdir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/yosys_examples/adder/layout
set techname=gscl45nm
set scriptdir=/usr/local/share/qflow/scripts
set bindir=/usr/local/share/qflow/bin
set logdir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/yosys_examples/adder/log
#-------------------------------------------

