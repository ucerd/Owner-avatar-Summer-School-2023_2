#!/bin/tcsh -f
#-------------------------------------------
# qflow variables for project ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/yosys_examples/dotprod
#-------------------------------------------

set qflowversion=1.4.100
set projectpath=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/yosys_examples/dotprod
set techdir=/home/ucerd-pc/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/yosys_examples/dotprod/tech
set sourcedir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/yosys_examples/dotprod/source
set synthdir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/yosys_examples/dotprod/synthesis
set layoutdir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/yosys_examples/dotprod/layout
set techname=sky130_fd_sc_ls
set scriptdir=/usr/local/share/qflow/scripts
set bindir=/usr/local/share/qflow/bin
set logdir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/yosys_examples/dotprod/log
#-------------------------------------------

