#!/bin/tcsh -f
#-------------------------------------------
# qflow variables for project ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL
#-------------------------------------------

set qflowversion=1.4.100
set projectpath=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL
set techdir=/usr/local/share/qflow/tech/osu035
set sourcedir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL/source
set synthdir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL/synthesis
set layoutdir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL/layout
set techname=osu035
set scriptdir=/usr/local/share/qflow/scripts
set bindir=/usr/local/share/qflow/bin
set logdir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL/log
#-------------------------------------------

