#!/bin/tcsh -f
#-------------------------------------------
# qflow exec script for project ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL
#-------------------------------------------

/usr/local/share/qflow/scripts/yosys.sh ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL main_processor ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL/source/Processor.v || exit 1
# /usr/local/share/qflow/scripts/graywolf.sh -d ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL main_processor || exit 1
# /usr/local/share/qflow/scripts/vesta.sh  ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL main_processor || exit 1
# /usr/local/share/qflow/scripts/qrouter.sh ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL main_processor || exit 1
# /usr/local/share/qflow/scripts/vesta.sh  -d ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL main_processor || exit 1
# /usr/local/share/qflow/scripts/magic_db.sh ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL main_processor || exit 1
# /usr/local/share/qflow/scripts/magic_drc.sh ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL main_processor || exit 1
# /usr/local/share/qflow/scripts/netgen_lvs.sh ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL main_processor || exit 1
# /usr/local/share/qflow/scripts/magic_gds.sh ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL main_processor || exit 1
# /usr/local/share/qflow/scripts/cleanup.sh ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL main_processor || exit 1
# /usr/local/share/qflow/scripts/cleanup.sh -p ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL main_processor || exit 1
# /usr/local/share/qflow/scripts/magic_view.sh ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/Processor-NAMAL main_processor || exit 1
