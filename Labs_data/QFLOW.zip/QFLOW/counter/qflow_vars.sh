#!/bin/tcsh -f
#-------------------------------------------
# qflow variables for project ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/counter
#-------------------------------------------

set qflowversion=1.4.100
set projectpath=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/counter
set techdir=/usr/local/share/qflow/tech/osu018
set sourcedir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/counter/source
set synthdir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/counter/synthesis
set layoutdir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/counter/layout
set techname=osu018
set scriptdir=/usr/local/share/qflow/scripts
set bindir=/usr/local/share/qflow/bin
set logdir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/counter/log
#-------------------------------------------

