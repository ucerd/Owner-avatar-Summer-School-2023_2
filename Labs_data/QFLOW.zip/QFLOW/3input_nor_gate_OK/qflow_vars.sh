#!/bin/tcsh -f
#-------------------------------------------
# qflow variables for project ~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/3input_nor_gate_OK
#-------------------------------------------

set qflowversion=1.4.100
set projectpath=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/3input_nor_gate_OK
set techdir=/usr/local/share/qflow/tech/osu050
set sourcedir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/3input_nor_gate_OK/source
set synthdir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/3input_nor_gate_OK/synthesis
set layoutdir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/3input_nor_gate_OK/layout
set techname=osu050
set scriptdir=/usr/local/share/qflow/scripts
set bindir=/usr/local/share/qflow/bin
set logdir=~/Desktop/Secure_Processor_based_Chip_Design_Summer_School/Labs/QFLOW/3input_nor_gate_OK/log
#-------------------------------------------

